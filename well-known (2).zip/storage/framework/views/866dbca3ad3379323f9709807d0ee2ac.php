<?php $__env->startSection('main'); ?>
<div class="container-fluid py-4">
      <div class="row">
      <div class="col-12">
            <div class="card mb-2">
                <div class="card-body px-2 pt-2 pb-2">
                    <a href="<?php echo e(route('rooms.index')); ?>" class="btn btn-small btn-warning">Rooms</a>
                    <a href="<?php echo e(route('room-types.index')); ?>" class="btn btn-small btn-primary">Room Types</a>
                    <a href="<?php echo e(route('bed-types.index')); ?>" class="btn btn-small btn-primary">Bed Types</a>
                    <a href="<?php echo e(route('amenities.index')); ?>" class="btn btn-small btn-primary">Amenities</a>
                    <a href="<?php echo e(route('complements.index')); ?>" class="btn btn-small btn-primary">Complements</a>
                    <a href="<?php echo e(route('addonservices.index')); ?>" class="btn btn-small btn-primary">Add On Services</a>
                </div>
            </div>
        </div>
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-between">
              <h6>List Of Rooms</h6>
              <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-small btn-primary">Back</a>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">#</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Room No</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Room Type</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Status</th>
                      <th class="text-secondary opacity-7 text-end">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td>
                        <p class="text-xs font-weight-small mb-0"><?php echo e($rooms->firstItem() + $key); ?></p>
                      </td>
                      <td>
                        <p class="text-xs font-weight-bold mb-0"><?php echo e($room->room_number); ?></p>
                      </td>
                      <td>
                        <p class="text-xs font-weight-bold mb-0"><?php echo e($room->roomType->name ?? ''); ?></p>
                      </td>
                      </td>
                      <td>
                        <p class="text-xs font-weight-bold mb-0"><?php echo e($room->status == 1 ? "Active" : "Disabled"); ?></p>
                      </td>
                      <td class="text-end">
                        <a href="<?php echo e(route('rooms.show',$room->id)); ?>" class="btn btn-info font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                          View
                        </a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td class="text-center" colspan="7">
                            No Data Found!
                      </td>
                    </tr>
                    <?php endif; ?>
                  </tbody>
                </table>
                <div class="col-12 d-flex justify-content-center">
                    <?php echo e($rooms->links('admin.layouts.pagination')); ?>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\Hotel-Booking\resources\views/admin/rooms/index.blade.php ENDPATH**/ ?>