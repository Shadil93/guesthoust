<?php $__env->startSection('main'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="card shadow-lg my-2">
            <div class="card-body p-3">
                <div class="row gx-4">
                    <div class="col-auto my-auto">
                        <div class="h-100">
                            <h5 class="mb-1">Booking Number: </h5>
                            #<?php echo e($booking->booking_number); ?>

                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-item-end">
                            <div class="d-flex justify-content-between align-item-center me-2">
                                <span class="btn btn-success me-2"></span>
                                Active
                            </div>
                            <div class="d-flex justify-content-between align-item-center me-2">
                                <span class="btn btn-warning me-2"></span>
                                Checked Out
                            </div>
                            <div class="d-flex justify-content-between align-item-center me-2">
                                <span class="btn btn-danger me-2"></span>
                                Cancelled
                            </div>
                    </div>
                </div> 
            </div>
        </div>  
    </div>
    <div class="card shadow-lg my-4">
        <div class="card-body p-3">
            <div class="row gx-4">
                <div class="col-auto my-auto">
                    <div class="h-100">
                        <h5 class="mb-1">Booked Rooms</h5>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-4">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Booked For</th>
                                        <th>Room Numbers</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $bookedRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bookedRoom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <?php
                                            $cancellationFee = $bookedRoom->where('status', Status::ROOM_ACTIVE)->sum('cancellation_fee');
                                            $totalFare = $bookedRoom->where('status', Status::ROOM_ACTIVE)->sum('fare');
                                            $shouldRefund = $totalFare - $cancellationFee;
                                            $activeBooking = $bookedRoom->where('status', Status::ROOM_ACTIVE)->count();
                                            $bookedRoom = $bookedRoom->sortBy('room_id');
                                        ?>

                                        

                                        <td>
                                            <?php echo e($key); ?>

                                        </td>

                                        <td>
                                            <div class="text-center">
                                                <?php $__currentLoopData = $bookedRoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->status == Status::BOOKED_ROOM_CANCELED): ?>
                                                        <span class="btn btn-danger"><?php echo e($item->room->room_number); ?> <br> <?php echo e($item->room->roomType->name); ?>  </span>
                                                    <?php elseif($item->status == status::BOOKED_ROOM_CHECKOUT): ?>
                                                        <span class="btn btn-warning"><?php echo e($item->room->room_number); ?> <br> <?php echo e($item->room->roomType->name); ?></span>
                                                    <?php elseif($item->status == Status::BOOKED_ROOM_ACTIVE): ?>
                                                        <span class="btn btn-success"><?php echo e($item->room->room_number); ?><br><?php echo e($item->room->roomType->name); ?><br>
                                                        <?php if(now()->toDateString() <= $item->booked_for): ?>
                                                            <button class="cancel-btn btn btn-danger mt-4 cancelBookingBtn" data-fare="<?php echo e($item->fare); ?>" data-id="<?php echo e($item->id); ?>" data-room_number="<?php echo e($item->room->room_number); ?>" data-should_refund="<?php echo e($item->fare - $item->cancellation_fee); ?>" type="button">Cancel</button>
                                                        <?php endif; ?>
                                                        </span>  
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <button <?php if(!$activeBooking || $key < now()->format('Y-m-d')): ?> disabled <?php endif; ?> class="btn btn-danger cancelBookingBtn" data-booked_for="<?php echo e($key); ?>" data-fare="<?php echo e($totalFare); ?>" data-should_refund="<?php echo e($shouldRefund); ?>" type="button">Cancel Booking</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td class="text-center" colspan="100%">No Rooms Found!</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div> 
        </div>
    </div>  
    
    <!-- Cancel Model -->
    <div class="modal fade" id="cancelBookingModal" role="dialog" tabindex="-1">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"></h5>
                        <button aria-label="Close" class="close" data-bs-dismiss="modal" type="button">
                            <i class="las la-times"></i>
                        </button>
                    </div>
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <input name="booked_for" type="hidden" value="">
                            <div class="row justify-content-center">
                                <div class="col-10 bg-danger p-3 rounded">
                                    <div class="d-flex flex-wrap justify-content-between gap-2">
                                        <h6 class="text-white">Fare</h6>
                                        <span class="text-white totalFare"></span>
                                    </div>

                                    <div class="d-flex flex-wrap justify-content-between gap-2 mt-2">
                                        <h6 class="text-white">Refundable Amount</h6>
                                        <span class="text-white refundableAmount"></span>
                                    </div>
                                </div>

                            </div>

                        </div>
                        <div class="modal-footer">
                            <h6 class="w-100">Are you sure to cancel this booking?</h6>
                            <button aria-label="Close" class="btn btn--dark" data-bs-dismiss="modal" type="button">No</button>
                            <button class="btn btn--primary" type="submit">Yes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Cancel Model -->
    <?php $__env->startPush('scripts'); ?>
    <script>
        (function($) {
            "use strict";

            $('.cancelBookingBtn').on('click', function() {
                let modal = $('#cancelBookingModal');
                let data = $(this).data();
                let action;
                if (data.booked_for) {
                    action = `<?php echo e(route('booked.day.cancel', $booking->id)); ?>`;
                    modal.find('[name=booked_for]').val(data.booked_for);
                } else {
                    action = `<?php echo e(route('booked.room.cancel', '')); ?>/${data.id}`;
                }

                modal.find('.modal-title').text(`Cancel Booking`);
                modal.find('form').attr('action', action);
                modal.find('.totalFare').text(data.fare);
                modal.find('.refundableAmount').text(data.should_refund);
                modal.modal('show');
            });

        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/suhas/WORK/hotel-booking/resources/views/admin/reservations/booked_rooms.blade.php ENDPATH**/ ?>