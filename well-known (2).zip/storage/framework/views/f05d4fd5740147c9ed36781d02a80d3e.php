<?php $__env->startSection('main'); ?>

<style>
    .custom-table { border-collapse: collapse; width: 100%;}
    .custom-table th, .custom-table td { border: 1px solid #dee2e6; padding: 8px; text-align: center; }
</style>

    <div class="container-fluid py-4">
        <div class="row">
            <div class="col-12">
                <div class="card mb-2">
                    <div class="card-header pb-0 d-flex justify-content-between">
                        <div>
                            <a href="<?php echo e(route('reports.custom')); ?>" class="btn btn-small btn-warning">Summary</a>
                            <a href="<?php echo e(route('reports.monthly')); ?>" class="btn btn-small btn-primary">Monthly Summary</a>
                            <a href="<?php echo e(route('reports.yearly')); ?>" class="btn btn-small btn-primary">Yearly Summary</a>
                            <a href="<?php echo e(route('reports.collection')); ?>" class="btn btn-small btn-primary">Collection Report</a>
                            <a href="<?php echo e(route('reports.bookings')); ?>" class="btn btn-small btn-primary">Booking Report</a>
                        </div>
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-small btn-primary">Back</a>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0 px-4">
                            <form action="<?php echo e(route('reports.custom')); ?>" method="GET">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="start_date">Start Date:</label>
                                            <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo e($startDate ?? now()->toDateString()); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label for="end_date">End Date:</label>
                                            <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo e($endDate ?? now()->toDateString()); ?>">
                                        </div>
                                    </div>
                                    <div class="col-md-2 mt-4">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                    <div class="col-md-3 mt-4">
                                        <a href="<?php echo e(route('reports.custom', ['start_date' => $startDate, 'end_date' => $endDate, 'pdf' => 1])); ?>" class="btn btn-danger">Download PDF</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0 d-flex justify-content-center">
                        <h6> Booking Summary BTW <?php echo e(\Carbon\Carbon::parse($startDate)->format('d M Y')); ?> and <?php echo e(\Carbon\Carbon::parse($endDate)->format('d M Y')); ?></h6>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                        <div class="table-responsive p-0 m-2">
                            <table class="custom-table ">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Number of Bookings</th>
                                        <th>Total Collection</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $totalBookings = 0; $totalCollection = 0; ?>
                                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $totalBookings += $data['bookingCount'];
                                            $totalCollection += $data['totalCollection'];
                                        ?>
                                        <tr>
                                            <td><?php echo e(\Carbon\Carbon::parse($data->date)->format('d-m-Y')); ?></td>
                                            <td><?php echo e($data->bookingCount); ?></td>
                                            <td><?php echo e($data->totalCollection); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><strong>Grand Total</strong></td>
                                        <td><strong><?php echo e($totalBookings); ?></strong></td>
                                        <td><strong><?php echo e($totalCollection); ?></strong></td>
                                    </tr>
                                </tbody>
                                
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\Hotel-Booking\resources\views/admin/reports/custom.blade.php ENDPATH**/ ?>