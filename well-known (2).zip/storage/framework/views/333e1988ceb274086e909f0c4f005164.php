<?php $__env->startSection('main'); ?>

<style>
  .custom-table {
      border-collapse: collapse;
      width: 100%;
  }

  .custom-table th,
  .custom-table td {
      border: 1px solid #dee2e6;
      padding: 8px;
      text-align: center; 
  }
</style>
    <div class="container-fluid py-4">
        <div class="row">
          <div class="col-12">
            <div class="card mb-2">
                <div class="card-header pb-0 d-flex justify-content-between">
                    <div>
                        <a href="<?php echo e(route('reports.custom')); ?>" class="btn btn-small btn-primary">Summary</a>
                        <a href="<?php echo e(route('reports.monthly')); ?>" class="btn btn-small btn-warning">Monthly Summary</a>
                        <a href="<?php echo e(route('reports.yearly')); ?>" class="btn btn-small btn-primary">Yearly Summary</a>
                        <a href="<?php echo e(route('reports.collection')); ?>" class="btn btn-small btn-primary">Collection Report</a>
                        <a href="<?php echo e(route('reports.bookings')); ?>" class="btn btn-small btn-primary">Booking Report</a>
                    </div>
                    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-small btn-primary">Back</a>
                </div>
            </div>
          </div>
            <div class="col-12">
                <div class="card mb-4">
                    <div class="card-header pb-0 d-flex justify-content-between">
                        <h6>Monthly Booking Summary</h6>
                    </div>
                    <div class="card-body px-0 pt-0 pb-2">
                      <div class="table-responsive p-0 px-4">
                            <div class="row">
                                <div class="col-md-2">
                                    <form action="<?php echo e(route('reports.monthly')); ?>" method="GET">
                                        <select class="form-control" name="selected_month" onchange="this.form.submit()">
                                          <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthNumber => $monthName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($selectedMonth->copy()->setMonth($monthNumber)->format('Y-m')); ?>" <?php echo e($selectedMonth->format('m') === $monthNumber ? 'selected' : ''); ?>>
                                                  <?php echo e($monthName); ?>

                                              </option>
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </form>
                                </div>
                                <div class="col-md-3">
                                    <a href="<?php echo e(route('reports.monthly', ['selected_month' => $selectedMonth->format('Y-m'), 'pdf' => 1])); ?>" class="btn btn-danger mx-3">Download PDF</a>
                                </div>
                            </div>
                      </div>
                  </div>
              </div>
          </div>
          <div class="col-12">
              <div class="card mb-4">
                  <div class="card-header pb-0 d-flex justify-content-center">
                      <h6>Booking Summary for <?php echo e($selectedMonth->format('F Y')); ?></h6>
                  </div>
                  <div class="card-body px-0 pt-0 pb-2 m-2">
                      <div class="table-responsive p-0">
                          <table class="custom-table">
                              <thead>
                                  <tr>
                                      <th>Date</th>
                                      <th>Number of Bookings</th>
                                      <th>Total Collection</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <?php
                                      $grandTotalCollection = 0;
                                      $grandTotalBooking = 0;
                                  ?>
                                  <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $bookingData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <?php
                                          $grandTotalBooking += $bookingData['bookingCount'];
                                          $grandTotalCollection += $bookingData['totalCollection'];
                                      ?>
                                      <tr>
                                          <td><?php echo e(\Carbon\Carbon::parse($bookingData->date )->format('d-m-Y')); ?></td>
                                          <td><?php echo e($bookingData->bookingCount); ?></td>
                                          <td><?php echo e($bookingData->totalCollection); ?></td>
                                      </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                      <td><strong>Grand Total</strong></td>
                                      <td><strong><?php echo e($grandTotalBooking); ?></strong></td>
                                      <td><strong><?php echo e($grandTotalCollection); ?></strong></td>
                                  </tr>
                              </tbody>
                          </table>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/simbitx6/kdgh.simbillsoft.in/resources/views/admin/reports/index.blade.php ENDPATH**/ ?>