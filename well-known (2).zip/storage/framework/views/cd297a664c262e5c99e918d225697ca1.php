<?php $__env->startSection('main'); ?>
<div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
            <div class="card mb-2">
                <div class="card-body px-2 pt-2 pb-2">
                    <a href="<?php echo e(route('reservations.index')); ?>" class="btn btn-small btn-primary">All Bookings</a>
                    <a href="<?php echo e(route('todays.checkin')); ?>" class="btn btn-small btn-primary">Today's Checkin</a>
                    <a href="<?php echo e(route('todays.checkout')); ?>" class="btn btn-small btn-primary">Today's Checkout</a>
                    <a href="<?php echo e(route('reservations.active')); ?>" class="btn btn-small btn-primary">Active Bookings</a>
                    <a href="<?php echo e(route('reservations.checkedout')); ?>" class="btn btn-small btn-primary">Checked Out Bookings</a>
                    <a href="<?php echo e(route('reservations.canceled')); ?>" class="btn btn-small btn-primary">Cancelled Bookings</a>
                </div>
            </div>
        </div>
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-between">
              <h6><?php echo e($pageTitle ?? ''); ?></h6>
              <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-small btn-primary">Back</a>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">#</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Booking Number</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Guest</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Checkin - Checkout</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Total Amount</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Total Paid</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Total Due</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Status</th>
                      <th class="text-secondary opacity-7 text-end">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td>
                        <p class="text-xs font-weight-small mb-0"><?php echo e($key + 1); ?></p>
                      <td>
                        <span class="fw-bold">#<?php echo e($booking->booking_number); ?></span><br>
                        <em class="text-muted text--small"><?php echo e($booking->created_at); ?></em>
                      </td>
                      <td>
                        <span class="small"><?php echo e($booking->guest_details->name); ?></span>
                        <br>
                        <span class="fw-bold"><?php echo e($booking->guest_details->email); ?></span>
                      </td>
                      <td>
                        <?php echo e($booking->check_in); ?>

                        <br>
                        <?php echo e($booking->check_out); ?>

                      </td>
                      <td><?php echo e('INR '.$booking->total_amount); ?></td>
                      <td><?php echo e('INR '.$booking->paid_amount); ?></td>

                      <?php
                          $due = $booking->total_amount - $booking->paid_amount;
                      ?>

                      <td class="<?php if($due < 0): ?> text--danger <?php elseif($due > 0): ?> text--warning <?php endif; ?>">
                          <?php echo e('INR'); ?><?php echo e($due); ?>

                      </td>
                      <td>
                        <?php echo $booking->statusBadge; ?>
                      </td>
                      <td class="text-end">
                        <a href="<?php echo e(route('reservations.show',$booking->id)); ?>" class="btn btn-secondary font-weight-bold text-xs me-2" data-toggle="tooltip" data-original-title="Edit user">
                          Details
                        </a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td class="text-center" colspan="3">
                            No Data Found!
                      </td>
                    </tr>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/suhas/WORK/hotel-booking/resources/views/admin/reservations/list.blade.php ENDPATH**/ ?>