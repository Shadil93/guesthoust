<?php $__env->startSection('main'); ?>
<div class="container-fluid py-4">
      <div class="row">
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-between">
              <h6>Rooms</h6>
              <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-small btn-primary">Back</a>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
                <div class="row m-3">
                    <div class="col-md-12">
                        <h3><?php echo e($room->roomType->name ?? ''); ?></h3>
                        <p>Room Number : <strong><?php echo e($room->room_number); ?></strong></p>
                    </div>
                    <div class="col-md-6">
                        <h4>Amenities</h4>
                        <?php if($room->amenities): ?>
                        <ul>
                            <?php $__currentLoopData = $room->amenities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $amenity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($amenity->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </ul>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <h4>Complements</h4>
                        <?php if($room->complements): ?>
                        <ul>
                            <?php $__currentLoopData = $room->complements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $complement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($complement->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projects\Hotel-Booking\resources\views/admin/rooms/show.blade.php ENDPATH**/ ?>