<?php $__env->startSection('main'); ?>
<?php
    $totalFare = $booking->bookedRooms->sum('fare');
    $totalTaxCharge = $booking->bookedRooms->sum('tax_charge');
    $canceledFare = $booking->bookedRooms->where('status', 3)->sum('fare');
    $canceledTaxCharge = $booking->bookedRooms->where('status', 3)->sum('tax_charge');
    $due = $booking->total_amount - $booking->paid_amount;
?>
<div class="card shadow-lg mx-4">
        <div class="card-header pb-0 d-flex justify-content-between"> 
            <h6> Reservation Details
                <div class="h-100">
                    <?php
                        echo $booking->status_badge;
                    ?>
                </div>
            </h6>
            <a href="<?php echo e(route('reservations.index')); ?>" class="btn btn-small btn-primary">Back</a>
        </div>
      <div class="card-body p-3">
        <div class="row gx-4">
          <div class="col-auto my-auto">
            <div class="mt-4">
                  <a href="<?php echo e(route('reservations.booked.rooms',$booking->id)); ?>" class="btn btn-sm btn-outline-primary me-1">Booked Rooms</a>
                  <!--<a class="btn btn-sm btn-outline-primary me-1">Add On Service</a>-->
                  <a href="<?php echo e(route('reservations.payment',$booking->id)); ?>" class="btn btn-sm btn-outline-primary me-1">Payment</a>
                  <?php if($booking->status == 1): ?>
                    <?php if($booking->key_status == 0): ?>
                            <a class="btn btn-sm btn-outline-primary me-1" href="<?php echo e(route('reservations.checkin',$booking->id)); ?>">
                                Checkin
                            </a>
                    <?php endif; ?>
                    <?php if($booking->key_status == 1): ?>
                        <a href="<?php echo e(route('reservations.checkout', $booking->id)); ?>" class="btn btn-sm btn-outline-primary me-1">Check Out</a>
                    <?php endif; ?>

                  <?php endif; ?>
                  <?php if($booking->status == 9): ?>
                    <a  href="<?php echo e(route('generate_invoice',$booking->id)); ?>" target="_blank" class="btn btn-sm btn-outline-primary me-1">Invoice</a>
                  <?php endif; ?> 
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header pb-0">
              <div class="d-flex justify-content-between">
                <h5 class="text-uppercase text-sm">Booking Information</h5>
              </div>
            </div>
            <div class="card-body">
              <hr class="horizontal dark mt-0">
              <div class="row">
                <div class="col-md-6 mt-4">
                    <span class="font-weight-light">Booking Number </span> 
                    <h5>#<?php echo e($booking->booking_number); ?></h5>
                    <span class="font-weight-light">Booked At   </span> 
                    <h5><?php echo e($booking->created_at->setTimezone('Asia/Kolkata')->format('d M Y h:i:s A')); ?></h5>
                    <span class="font-weight-light">Checkin  </span> 
                    <h5><?php echo e(\Carbon\Carbon::parse($booking->check_in)->format('d-m-Y')); ?></h5>
                    <span class="font-weight-light">Checkout  </span> 
                    <h5><?php echo e(\Carbon\Carbon::parse($booking->check_out)->format('d-m-Y')); ?></h5>
                </div>
                <div class="col-md-6 mt-4">
                    <span class="font-weight-light">Total Rooms  </span> 
                    <h5><?php echo e($booking->bookedRooms->count()); ?></h5>
                    <span class="font-weight-light">Total Charge </span> 
                    <h5> ₹ <?php echo e(number_format($booking->total_amount, 2)); ?></h5>
                    <span class="font-weight-light">Paid Amount  </span> 
                    <h5>₹ <?php echo e(number_format($booking->paid_amount, 2)); ?></h5>
                    <?php if($due < 0): ?>
                    <span class="font-weight-light">Refundable  </span> 
                    <h5>₹ <?php echo e(number_format(abs($due), 2)); ?></h5>
                    <?php else: ?>
                    <span class="font-weight-light">Receivable From Customer  </span> 
                    <h5 class="<?php if($due > 0): ?> text-danger <?php else: ?> text-success <?php endif; ?>"> ₹ <?php echo e(number_format(abs($due), 2)); ?></h5>
                    <?php endif; ?>
                </div>
                <div class="col-md-12 mt-4">
                    <hr class="horizontal dark mt-0">
                    <div class="d-flex justify-content-between">
                        <div>
                            <span class="font-weight-light">Checked In At  </span> 
                            <h5>
                                <?php echo e($booking->checked_in_at ? \Carbon\Carbon::parse($booking->checked_in_at)->format('d-m-Y h:i:s A') : 'N/A'); ?>

                            </h5>
                        </div>
                        <div>
                            <span class="font-weight-light">Checked Out At  </span> 
                            <h5>
                                <?php echo e($booking->checked_out_at ? \Carbon\Carbon::parse($booking->checked_out_at)->format('d-m-Y h:i:s A') : 'N/A'); ?>

                            </h5>
                        </div>
                    </div>
                </div>
              </div>        
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-profile">
            <div class="card-header text-center border-0 pt-0 pt-lg-2 pb-4 pb-lg-3">
              <div class="d-flex justify-content-between">
                <h5 class="text-uppercase text-sm">Guest Details</h5>
              </div>
            </div>
            <div class="card-body pt-0">
              <hr class="horizontal dark mt-0">
              <div class="mt-4">
                 <span class="font-weight-light">Name </span> 
                 <h5><?php echo e($booking->guest_details->name); ?></h5>
                 <span class="font-weight-light">Email : </span> 
                 <h5><?php echo e($booking->guest_details->email ?? ''); ?></h5>
                 <span class="font-weight-light">Mobile : </span> 
                 <h5><?php echo e($booking->guest_details->mobile); ?></h5>
                 <span class="font-weight-light">Address : </span> 
                 <h5><?php echo e($booking->guest_details->address); ?></h5>
                 <span class="font-weight-light">ID Type : </span> 
                 <h5><?php echo e($booking->guest_details->id_card_type); ?></h5>
                 <span class="font-weight-light">ID Number : </span> 
                 <h5><?php echo e($booking->guest_details->id_card_number); ?></h5>
                 <span class="font-weight-light">No Of Adults : </span> 
                 <h5><?php echo e($booking->no_adults ?? 0); ?></h5>
                 <span class="font-weight-light">No of Childrens : </span> 
                 <h5><?php echo e($booking->no_childs ?? 0); ?></h5>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row m-2">
        <div class="card">
            <div class="card-header pb-0">
              <div class="d-flex justify-content-between">
                <h5 class="text-uppercase text-sm">Booked Rooms</h5>
              </div>
            </div>
            <div class="card-body">
              <hr class="horizontal dark mt-0">
                <div class="table-responsive-sm">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="text-center">Booked For</th>
                                <th>Room Type</th>
                                <th>Room No</th>
                                <th class="text-end">Fare / Night</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $booking->bookedRooms->groupBy('booked_for'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookedRoom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $bookedRoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if($loop->first): ?>
                                            <td class="bg-date text-center" rowspan="<?php echo e(count($bookedRoom)); ?>">
                                                <?php echo e(\Carbon\Carbon::parse($booked->booked_for)->format('d-m-Y')); ?>

                                            </td>
                                        <?php endif; ?>
                                        <td class="text-center" data-label="Room Type">
                                            <?php echo e($booked->room->roomType->name ?? 'NA'); ?>

                                        </td>
                                        <td data-label="Room No.">
                                            <?php echo e($booked->room->room_number ?? 'NA'); ?>

                                            <?php if($booked->status == 3): ?>
                                                <span class="text-danger text-sm">(Canceled)</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end" data-label="Fare">
                                           ₹ <?php echo e(number_format($booked->fare , 2)); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-end" colspan="3">
                                    <span class="fw-bold">Total Fare</span>
                                </td>
                                <td class="fw-bold text-end">
                                     ₹ <?php echo e(number_format($totalFare , 2)); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
      </div>
      <!--<div class="row m-2">-->
      <!--  <div class="card">-->
      <!--      <div class="card-header pb-0">-->
      <!--        <div class="d-flex justify-content-between">-->
      <!--          <h5 class="text-uppercase text-sm">Add On Services</h5>-->
      <!--        </div>-->
      <!--      </div>-->
      <!--      <div class="card-body">-->
      <!--        <hr class="horizontal dark mt-0">-->
      <!--          <?php if($booking->usedExtraService->count()): ?>-->
      <!--              <div class="table-responsive--sm">-->
      <!--                  <table class="table table-striped">-->
      <!--                      <thead>-->
      <!--                          <tr>-->
      <!--                              <th>Date</th>-->
      <!--                              <th>Room No.</th>-->
      <!--                              <th>Service</th>-->
      <!--                              <th>Total</th>-->
      <!--                          </tr>-->
      <!--                      </thead>-->
      <!--                      <tbody>-->
      <!--                          <?php $__currentLoopData = $booking->usedExtraService->groupBy('service_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
      <!--                              <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
      <!--                                  <tr>-->
      <!--                                      <?php if($loop->first): ?>-->
      <!--                                          <td class="text-center" data-label="Date" rowspan="<?php echo e(count($services)); ?>">-->
      <!--                                              <?php echo e($service->service_date); ?>-->
      <!--                                          </td>-->
      <!--                                      <?php endif; ?>-->
      <!--                                      <td data-label="Room No.">-->
      <!--                                          <?php echo e($service->room->room_number); ?>-->
      <!--                                      </td>-->
      <!--                                      <td data-label="Service">-->
      <!--                                          <?php echo e($service->extraService->name); ?><br>-->
      <!--                                          <?php echo e($service->unit_price); ?> x <?php echo e($service->qty); ?>-->
      <!--                                      </td>-->
      <!--                                      <td data-label="Total">-->
      <!--                                          <?php echo e($service->total_amount); ?>-->
      <!--                                      </td>-->
      <!--                                  </tr>-->
      <!--                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
      <!--                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
      <!--                           <tr>-->
      <!--                              <td class="text-end" colspan="3">-->
      <!--                                  <span class="fw-bold">Total</span>-->
      <!--                              </td>-->
      <!--                              <td class="fw-bold text-end">-->
      <!--                                  <?php echo e($booking->service_cost); ?>-->
      <!--                              </td>-->
      <!--                          </tr>-->
      <!--                      </tbody>-->
      <!--                  </table>-->
      <!--              </div>-->
      <!--          <?php else: ?>-->
      <!--              <div class="text-center">-->
      <!--                  <h6 class="p-3">No add on service used</h6>-->
      <!--              </div>-->
      <!--          <?php endif; ?>-->
      <!--      </div>-->
      <!--  </div> -->
      <!--</div>-->
      <?php
        $receivedPyaments = $booking->payments->where('type', 'RECEIVED');
        $returnedPyaments = $booking->payments->where('type', 'RETURNED');
    ?>
      <div class="row m-2">
        <div class="card">
            <div class="card-header pb-0">
              <div class="d-flex justify-content-between">
                <h5 class="text-uppercase text-sm">Payment Received</h5>
              </div>
            </div>
            <div class="card-body">
              <hr class="horizontal dark mt-0">
                <div class="table-responsive-sm">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="text-center">Time</th>
                                <th>Payment Type</th>
                                <th class="text-end">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $receivedPyaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-start"><?php echo e(\Carbon\Carbon::parse($payment->created_at)->format('d-m-Y h:i:s A')); ?></td>
                                    <td>Cash Payment</td>
                                    <td class="text-end"> ₹ <?php echo e(number_format( $payment->amount , 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-end fw-bold" colspan="2">Total</td>
                                <td class="text-end fw-bold">
                                  ₹ <?php echo e(number_format($receivedPyaments->sum('amount') , 2)); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
      </div>
      <?php if($returnedPyaments->count()): ?>
      <div class="row m-2">
        <div class="card">
            <div class="card-header pb-0">
              <div class="d-flex justify-content-between">
                <h5 class="text-uppercase text-sm">Payment Returned</h5>
              </div>
            </div>
            <div class="card-body">
              <hr class="horizontal dark mt-0">
                <div class="table-responsive-sm">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="text-center">Time</th>
                                <th>Payment Type</th>
                                <th class="text-end">Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $returnedPyaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-start"><?php echo e(\Carbon\Carbon::parse($payment->created_at)->format('d-m-Y h:i:s A')); ?></td>
                                    <td>Cash Payment</td>
                                    <td>₹ <?php echo e(number_format($payment->amount , 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-end" colspan="2">
                                    <span class="fw-bold">Total</span>
                                </td>
                                <td class="text-end fw-bold">
                                    ₹ <?php echo e(number_format($returnedPyaments->sum('amount') , 2)); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
      </div>
      <?php endif; ?>
      <div class="row m-2">
        <div class="card">
            <div class="card-header pb-0">
              <div class="d-flex justify-content-between">
                <h5 class="text-uppercase text-sm">Payment Info</h5>
              </div>
            </div>
            <div class="card-body">
              <hr class="horizontal dark mt-0">
                <div class="table-responsive-sm">
                    <table class="table table-striped">
                        <tbody>
                            <tr>
                                <td>Total Fare</td>
                                <td>₹ <?php echo e(number_format($totalFare , 2)); ?></td>
                            </tr>
                            <tr>
                                <!--<td>Charge<small>(<?php echo e($booking->taxPercentage()); ?>%)</small></td>-->
                                <td>Tax</td>
                                <td>  ₹ <?php echo e(number_format($totalTaxCharge , 2)); ?></td>
                            </tr>
                            <tr>
                                <td>Canceled Tax</td>
                                <td>  ₹ <?php echo e(number_format($canceledTaxCharge , 2)); ?></td>
                            </tr>

                            <tr>
                                <td>Canceled</td>
                                <td>  ₹ <?php echo e(number_format($canceledFare , 2)); ?></td>
                            </tr>

                            <tr>
                                <td>Extra Service Charge</td>
                                <td>  ₹ <?php echo e(number_format($booking->service_cost , 2)); ?></td>
                            </tr>

                            <?php if($booking->extraCharge() > 0): ?>
                                <tr>
                                    <td>Other Charges</td>
                                    <td>  ₹ <?php echo e(number_format($booking->extraCharge() , 2)); ?></td>
                                </tr>
                            <?php endif; ?>

                            <?php if($booking->cancellation_fee > 0): ?>
                                <tr>
                                    <td>Cancellation Fee</td>
                                    <td>  ₹ <?php echo e(number_format($booking->cancellation_fee , 2)); ?></td>
                                </tr>
                            <?php endif; ?>

                            <tr>
                                <td class="fw-bold">Total Amount</td>
                                <td class="fw-bold">   ₹ <?php echo e(number_format($booking->total_amount , 2)); ?></td>
                            </tr>

                            <tr>
                                <td>Payment Received</td>
                                <td> ₹ <?php echo e(number_format($receivedPyaments->sum('amount') , 2)); ?></td>
                            </tr>

                            <tr>
                                <td>Refunded</td>
                                <td> ₹ <?php echo e(number_format($returnedPyaments->sum('amount') , 2)); ?></td>
                            </tr>

                            <?php $due = $booking->due(); ?>

                            <tr>
                                <?php if($due < 0): ?>
                                    <td class="text-warning fw-bold">Refundable</td>
                                    <td class="text-warning fw-bold">₹ <?php echo e(number_format(abs($due) , 2)); ?></td>
                                <?php else: ?>
                                    <td class="<?php if($due > 0): ?> text-danger <?php else: ?> text-success <?php endif; ?> fw-bold">Receivable from User</td>
                                    <td class="<?php if($due > 0): ?> text-danger <?php else: ?> text-success <?php endif; ?> fw-bold"> ₹ <?php echo e(number_format(abs($due) , 2)); ?></td>
                                <?php endif; ?>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> 
      </div>
    </div>

       


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/simbitx6/kdgh.simbillsoft.in/resources/views/admin/reservations/show.blade.php ENDPATH**/ ?>