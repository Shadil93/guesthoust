<?php $__env->startSection('main'); ?>
<?php
    $due = $booking->due() 
?>
<div class="card shadow-lg mx-4">
      <div class="card-body p-3">
        <div class="row gx-4">
          <div class="col-md-12">
            <div class="h-100">
              <h5 class="mb-1">
                Reservation Details
              </h5>
              <?php
                echo $booking->status_badge;
              ?>
            </div>
          </div>
          <div class="col-auto my-auto">
            <?php if($due > 0): ?>
            <div class="col-md-12">
                <div class="alert alert-danger">
                    The guest didn't pay the due payment for this booking yet. The checkout process can't be completed until the payment is settled. Please receive the due amount.
                </div>
            </div>
            <?php endif; ?>

            <?php if($due < 0): ?>
                <div class="col-md-12">
                    <div class="alert alert-danger">
                        The guest didn't receive the refundable amount for this booking yet. The checkout process can't be completed until the payment is settled. Please refund the amount.
                    </div>
                </div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid py-4">
      <div class="row">
        <div class="col-md-8">
          <div class="card">
            <div class="card-header pb-0">
              <div class="d-flex justify-content-between">
                <h5 class="text-uppercase text-sm">Booking Information</h5>
              </div>
            </div>
            <div class="card-body">
              <hr class="horizontal dark mt-0">
              <div class="row">
                <div class="col-md-6 mt-4">
                    <span class="font-weight-light">Booking Number </span> 
                    <h5>#<?php echo e($booking->booking_number); ?></h5>
                    <span class="font-weight-light">Booked At   </span> 
                    <h5><?php echo e($booking->created_at); ?></h5>
                    <span class="font-weight-light">Checkin  </span> 
                    <h5><?php echo e($booking->check_in); ?></h5>
                    <span class="font-weight-light">Checkout  </span> 
                    <h5><?php echo e($booking->check_out); ?></h5>
                </div>
                <div class="col-md-6 mt-4">
                    <span class="font-weight-light">Total Rooms  </span> 
                    <h5><?php echo e($booking->bookedRooms->count()); ?></h5>
                    <span class="font-weight-light">Total Charge </span> 
                    <h5><?php echo e($booking->total_amount); ?></h5>
                    <span class="font-weight-light">Paid Amount  </span> 
                    <h5><?php echo e($booking->paid_amount); ?></h5>
                    <?php if($due < 0): ?>
                    <span class="font-weight-light">Refundable  </span> 
                    <h5><?php echo e(abs($due)); ?></h5>
                    <?php else: ?>
                    <span class="font-weight-light">Receivable From Customer  </span> 
                    <h5 class="<?php if($due > 0): ?> text-danger <?php else: ?> text-success <?php endif; ?>"><?php echo e(abs($due)); ?></h5>
                    <?php endif; ?>
                </div>
                <div class="col-md-12 mt-4">
                    <hr class="horizontal dark mt-0">
                    <div class="d-flex justify-content-between">
                        <div>
                            <span class="font-weight-light">Checked In At  </span> 
                            <h5><?php echo e($booking->checked_in_at ? $booking->checked_in_at : 'N/A'); ?></h5>
                        </div>
                        <div>
                            <span class="font-weight-light">Checked Out At  </span> 
                            <h5><?php echo e($booking->checked_out_at  ? $booking->checked_out_at : 'N/A'); ?></h5>
                        </div>
                    </div>
                </div>
              </div>        
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h5 class="text-uppercase text-sm">Booked Rooms</h5>
                </div>
                <hr class="horizontal dark mt-0">
                <div class="table-responsive-sm">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th class="text-center">Booked For</th>
                                <th>Room Type</th>
                                <th>Room No</th>
                                <th class="text-end">Fare / Night</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $booking->bookedRooms->groupBy('booked_for'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookedRoom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $bookedRoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if($loop->first): ?>
                                            <td class="bg-date text-center" rowspan="<?php echo e(count($bookedRoom)); ?>">
                                                <?php echo e($booked->booked_for); ?>

                                            </td>
                                        <?php endif; ?>
                                        <td class="text-center" data-label="Room Type">
                                            <?php echo e($booked->room->roomType->name); ?>

                                        </td>
                                        <td data-label="Room No.">
                                            <?php echo e($booked->room->room_number); ?>

                                            <?php if($booked->status == 3): ?>
                                                <span class="text-danger text-sm">(Canceled)</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end" data-label="Fare">
                                            <?php echo e($booked->fare); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-end" colspan="3">
                                    <span class="fw-bold">Total Fare</span>
                                </td>
                                <td class="fw-bold text-end">
                                    <?php echo e($totalFare); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-2">
            <h5 class="card-title">Payment Info</h5>
        </div>
        <ul class="list-group">
            <li class="list-group-item">
                <span>Total Fare</span>
                <span class="text-end">+<?php echo e($totalFare); ?></span>
            </li>

            <li class="list-group-item">
                <span> Charge</span>
                <span class="text-end">+<?php echo e($totalTaxCharge); ?></span>
            </li>

            <li class="list-group-item">
                <span>Canceled Fare</span>
                <span class="text-end">-<?php echo e($canceledFare); ?></span>
            </li>

            <li class="list-group-item">
                <span>Canceled Charge</span>
                <span class="text-end">-<?php echo e($canceledTaxCharge); ?></span>
            </li>

            <li class="list-group-item">
                <span>Extra Service Charge</span>
                <span class="text-end">+<?php echo e($booking->service_cost); ?></span>
            </li>

            <li class="list-group-item">
                <span>Other Charges</span>
                <span class="text-end">+<?php echo e($booking->extraCharge()); ?></span>
            </li>

            <li class="list-group-item">
                <span>Cancellation Fee</span>
                <span class="text-end">+<?php echo e($booking->cancellation_fee); ?></span>
            </li>

            <li class="list-group-item">
                <span class="fw-bold">Total Amount</span>
                <span class="fw-bold text-end"> = <?php echo e($booking->total_amount); ?></span>
            </li>

        </ul>
    </div>
    <div class="card-body">
        <h5 class="card-title">Payment Summary</h5>
        <ul class="list-group">
            <li class="list-group-item">
                <span>Total Payment</span>
                <span>+<?php echo e($booking->total_amount); ?></span>
            </li>

            <li class="list-group-item">
                <span>Payment Received</span>
                <span>-<?php echo e($receivedPayments->sum('amount')); ?></span>
            </li>

            <li class="list-group-item">
                <span>Refunded</span>
                <span>-<?php echo e($returnedPayments->sum('amount')); ?></span>
            </li>

            <li class="list-group-item fw-bold">
                <?php if($due < 0): ?>
                    <span class="text-danger">Refundable </span>
                    <span class="text-danger"> = <?php echo e(abs($due)); ?></span>
                <?php else: ?>
                    <span>Receivable from User</span>
                    <span> = <?php echo e(abs($due)); ?></span>
                <?php endif; ?>
            </li>
        </ul>
    </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card card-profile">
            <div class="card-header text-center border-0 pt-0 pt-lg-2 pb-4 pb-lg-3">
              <div class="d-flex justify-content-between">
                <h5 class="text-uppercase text-sm">Guest Details</h5>
              </div>
            </div>
            <div class="card-body pt-0">
              <hr class="horizontal dark mt-0">
              <div class="mt-4">
                 <span class="font-weight-light">Name </span> 
                 <h5><?php echo e($booking->guest_details->name); ?></h5>
                 <span class="font-weight-light">Email : </span> 
                 <h5><?php echo e($booking->guest_details->email ?? ''); ?></h5>
                 <span class="font-weight-light">Mobile : </span> 
                 <h5><?php echo e($booking->guest_details->mobile); ?></h5>
                 <span class="font-weight-light">Address : </span> 
                 <h5><?php echo e($booking->guest_details->address); ?></h5>
                 <span class="font-weight-light">ID Type : </span> 
                 <h5><?php echo e($booking->guest_details->id_card_type); ?></h5>
                 <span class="font-weight-light">ID Number : </span> 
                 <h5><?php echo e($booking->guest_details->id_card_number); ?></h5>
                <div class="row">
                    <div class="row ms-1 me-1">
                        <a class="btn btn-lg btn-info flex-grow-1" href="<?php echo e(route('invoice', $booking->id)); ?>" target="_blank"><i class="las la-print"></i>Print Invoice</a>
                    </div>
                    <div class="row ms-1 me-1">
                        <a class="btn btn-lg btn-primary flex-grow-1" href="#"><i class="la la-money-bill"></i>Go To Payment</a>
                    </div>
                    <div class="row ms-1 me-1">
                        <button class="btn btn-lg btn-dark flex-grow-1 confirmationBtn" data-action="<?php echo e(route('reservations.checkout', $booking->id)); ?>" data-question="Are you sure, you want to check out this booking?"><i class="las la-sign-out-alt"></i>Check Out</button>
                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div id="confirmationModal" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmation Alert!</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <i class="las la-times"></i>
                </button>
            </div>
            <form action="" method="POST" id="confirmation-form">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <p class="question"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-bs-dismiss="modal">No</button>
                    <button type="submit" class="btn btn--primary">Yes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        (function($) {
            "use strict";
            $(document).on('click', '.confirmationBtn', function() {
                var modal = $('#confirmationModal');
                let data = $(this).data();
                modal.find('.question').text(`${data.question}`);
                modal.find('form').attr('action', `${data.action}`);
                modal.modal('show');
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>   


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/suhas/WORK/hotel-booking/resources/views/admin/reservations/check_out.blade.php ENDPATH**/ ?>