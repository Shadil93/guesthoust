<?php $__env->startSection('main'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="card shadow-lg my-2">
            <div class="card-body p-3">
                <div class="row gx-4">
                    <div class="col-auto my-auto">
                        <div class="h-100">
                            <h5 class="mb-1">Booking Number: </h5>
                            #<?php echo e($booking->booking_number); ?>

                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-item-end">
                            
                    </div>
                </div> 
            </div>
        </div>  
    </div>
    <div class="card shadow-lg my-4">
        <div class="card-body p-3">
            <div class="row gx-4">
                <div class="col-auto my-auto">
                    <div class="h-100">
                        <h5 class="mb-1">Booked Rooms</h5>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="mt-4">
                        <div class="table-responsive">
                            <table class="table">
                            <thead>
                                <tr>
                                    <th class="text-center">SL</th>
                                    <th>Room Number</th>
                                    <th>Room Type</th>
                                    <th>Fare</th>
                                    <th>Cancellation Fee</th>
                                    <th>Refundable</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $booking->activeBookedRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookedRoom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($bookedRoom->room->room_number); ?></td>
                                        <td> <?php echo e($bookedRoom->room->roomType->name); ?></td>
                                        <td><?php echo e($bookedRoom->fare); ?></td>
                                        <td><?php echo e($bookedRoom->cancellation_fee); ?></td>
                                        <td><?php echo e($bookedRoom->fare - $bookedRoom->cancellation_fee); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tfoot>
                                    <tr>
                                        <th class="text-end" colspan="4">Total</th>
                                        <th><?php echo e($booking->activeBookedRooms->sum('cancellation_fee')); ?></th>
                                        <th><?php echo e($booking->activeBookedRooms->sum('fare') - $booking->activeBookedRooms->sum('cancellation_fee')); ?></th>
                                    </tr>
                                </tfoot>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div> 
        </div>
        <div class="card-footer d-flex justify-content-end">
            <form action="<?php echo e(route('cancel.full', $booking->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button class="btn btn-primary" type="submit">Confirm Cancellation</button>
            </form>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/simbitx6/kdgh.simbillsoft.in/resources/views/admin/reservations/cancel.blade.php ENDPATH**/ ?>