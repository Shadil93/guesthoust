<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta content="IE=edge" http-equiv="X-UA-Compatible" />
    <meta content="IE=edge" http-equiv="X-UA-Compatible" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title></title>
    <link href="" rel="shortcut icon" type="image/png">
</head>

<body>
    <?php
        $extraService = count($booking->usedExtraService);
        $due = $booking->total_amount - $booking->paid_amount;
    ?>
    <header>
        <div class="row">
            <div class="col-12">
                <div class="list--row">
                    <div class="logo float-left">
                        <img alt="image" class="logo-img" src="">
                    </div>
                    <h6 class="float-right m-0" style="margin: 0;"> <?php echo e(date('d/m/Y')); ?></h6>
                </div>
            </div>
        </div>
    </header>
    <main>
        <div class="row">
            <div class="col-12">
                <div class="address list--row">
                    <div class="float-left">
                        <h5 class="primary-text d-block fw-md">Invoice To</h5>
                        <ul class="list" style="--gap: 0.3rem">
                            <li>
                                <div class="list list--row gap-5rem">
                                    <span class="strong">Name :</span>
                                    <span><?php echo e($booking->guest_details->name); ?></span>
                                </div>
                            </li>
                            <li>
                                <div class="list list--row gap-5rem">
                                    <span class="strong">Email :</span>
                                    <span><?php echo e($booking->guest_details->email); ?></span>
                                </div>
                            </li>
                            <li>
                                <div class="list list--row gap-5rem">
                                    <span class="strong">Mobile :</span>
                                    <span>+<?php echo e($booking->guest_details->mobile); ?></span>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="float-right">
                        <ul class="text-end">
                            <li>
                                <h5 class="primary-text d-block fw-md"> Bill Information </h5>
                            </li>

                            <li>
                                <span class="d-inline-block strong">Booking No</span>
                                <span class="d-inline-block"><?php echo e($booking->booking_number); ?></span>
                            </li>

                            <li>
                                <span class="d-inline-block strong">Total Amount :</span>
                                <span class="d-inline-block"><?php echo e($booking->total_amount); ?></span>
                            </li>
                            <li>
                                <span class="d-inline-block strong">Paid Amount :</span>
                                <span class="d-inline-block"><?php echo e($booking->paid_amount); ?></span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="body">
                    <h5 class="title">Room's Details</h5>
                    <table class="table-bordered custom-table table">
                        <thead>
                            <tr>
                                <th>Room No.</th>
                                <th>Room Type</th>
                                <th>Fare</th>
                            </tr>
                        </thead>
                        <?php
                            $activeBookedRooms = $booking->activeBookedRooms->groupBy('booked_for');
                            $totalFare = $booking->activeBookedRooms->sum('fare');
                        ?>

                        <tbody>
                            <?php $__currentLoopData = $activeBookedRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="custom-table__subhead">
                                    <td colspan="3" style="text-align: center;">
                                        <?php echo e($key); ?>

                                    </td>
                                </tr>
                                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booked): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-start"><?php echo e($booked->room->room_number); ?></td>
                                        <td><?php echo e($booked->room->roomType->name); ?></td>
                                        <td><?php echo e($booked->fare); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <tr class="custom-table__subhead">
                                <td class="text-end" colspan="2">Total Fare</td>
                                <td><?php echo e($totalFare); ?></td>
                            </tr>

                            <?php if(!$extraService): ?>

                                <?php if($booking->cancellation_fee > 0): ?>
                                    <tr class="custom-table__subhead">
                                        <td class="text-end" colspan="2">Cancellation Fee</td>
                                        <td><?php echo e($booking->cancellation_fee); ?></td>
                                    </tr>
                                <?php endif; ?>
                                <tr class="custom-table__subhead">
                                    <td class="text-end" colspan="2">Tax</td>
                                    <td><?php echo e($booking->tax_charge); ?></td>
                                </tr>
                                <?php if($booking->extraCharge() > 0): ?>
                                    <tr class="custom-table__subhead">
                                        <td class="text-end" colspan="2">Other Charges</td>
                                        <td><?php echo e($booking->extraCharge()); ?></td>
                                    </tr>
                                <?php endif; ?>

                                <tr class="custom-table__subhead">
                                    <td class="text-end" colspan="2">Total</td>
                                    <td><?php echo e($booking->total_amount); ?></td>
                                </tr>

                                <?php if($due > 0): ?>
                                    <tr class="custom-table__subhead">
                                        <td class="text-end" colspan="2">Due</td>
                                        <td><?php echo e($due); ?></td>
                                    </tr>
                                <?php elseif($due < 0): ?>
                                    <tr class="custom-table__subhead">
                                        <td class="text-end" colspan="2">Refundable</td>
                                        <td><?php echo e(abs($due)); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <?php if($extraService): ?>
                        <?php
                            $extraServices = $booking->usedExtraService->groupBy('service_date');
                        ?>
                        <div class="extra-service">
                            <div class="mt-10">
                                <h5 class="title">Service Details</h5>
                            </div>
                            <table class="table-bordered custom-table table">
                                <thead>
                                    <tr>
                                        <th>Room No</th>
                                        <th>Service</th>
                                        <th>Quantity</th>
                                        <th>Unit Price</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $extraServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $serviceItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="custom-table__subhead">
                                            <td colspan="5" style="text-align: center;"><?php echo e($key); ?></td>
                                        </tr>
                                        <?php $__currentLoopData = $serviceItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($service->room->room_number); ?></td>
                                                <td><?php echo e($service->extraService->name); ?></td>
                                                <td><?php echo e($service->qty); ?></td>
                                                <td><?php echo e($service->unit_price); ?></td>
                                                <td><?php echo e($service->total_amount); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="custom-table__subhead">
                                        <td class="text-end" colspan="4"><?php echo app('translator')->get('Total Charge'); ?></td>
                                        <td><?php echo e($booking->service_cost); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="summary avoid_page_break">
                            <div class="mt-10">
                                <h5 class="title">Billing Details</h5>
                            </div>
                            <table class="table-bordered custom-table table">
                                <tbody>
                                    <tr>
                                        <td class="text-end">Total Fare</td>
                                        <td><?php echo e($totalFare); ?></td>
                                    </tr>
                                    <?php if($booking->cancellation_fee > 0): ?>
                                        <tr>
                                            <td class="text-end">Cancellation Fee</td>
                                            <td><?php echo e($booking->cancellation_fee); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td class="text-end"> Charge</td>
                                        <td><?php echo e($booking->tax_charge); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-end">Service Charge</td>
                                        <td><?php echo e($booking->service_cost); ?></td>
                                    </tr>
                                    <?php if($booking->extraCharge() > 0): ?>
                                        <tr>
                                            <td class="text-end">Other Charges</td>
                                            <td><?php echo e($booking->extraCharge()); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td class="text-end">Total</td>
                                        <td><?php echo e($booking->total_amount); ?></td>
                                    </tr>

                                    <?php if($due > 0): ?>
                                        <tr class="text-end">
                                            <td class="text-end">Due</td>
                                            <td><?php echo e($due); ?> </td>
                                        </tr>
                                    <?php elseif($due < 0): ?>
                                        <tr class="text-end">
                                            <td class="text-end">Refundable</td>
                                            <td><?php echo e(abs($due)); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>
</body>

</html>
<?php /**PATH /home/suhas/WORK/hotel-booking/resources/views/admin/reservations/partials/invoice.blade.php ENDPATH**/ ?>