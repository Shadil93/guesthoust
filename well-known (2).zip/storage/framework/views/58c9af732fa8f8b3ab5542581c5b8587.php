<?php $__env->startSection('main'); ?>
<div class="container-fluid py-4">
      <div class="row">
      <div class="col-12">
            <div class="card mb-2">
                <div class="card-body px-2 pt-2 pb-2">
                    <a href="<?php echo e(route('rooms.index')); ?>" class="btn btn-small btn-primary">Rooms</a>
                    <a href="<?php echo e(route('room-types.index')); ?>" class="btn btn-small btn-primary">Room Types</a>
                    <a href="<?php echo e(route('bed-types.index')); ?>" class="btn btn-small btn-primary">Bed Types</a>
                    <a href="<?php echo e(route('amenities.index')); ?>" class="btn btn-small btn-primary">Amenities</a>
                    <a href="<?php echo e(route('complements.index')); ?>" class="btn btn-small btn-primary">Complements</a>
                    <a href="<?php echo e(route('addonservices.index')); ?>" class="btn btn-small btn-primary">Add On Services</a>
                </div>
            </div>
        </div>
        <div class="col-12">
          <div class="card mb-4">
            <div class="card-header pb-0 d-flex justify-content-between">
              <h6>List Of Bed Type</h6>
              <a href="<?php echo e(route('bed-types.create')); ?>" class="btn btn-small btn-primary">Add New</a>
            </div>
            <div class="card-body px-0 pt-0 pb-2">
              <div class="table-responsive p-0">
                <table class="table align-items-center mb-0">
                  <thead>
                    <tr>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">#</th>
                      <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Bed Type</th>
                      <th class="text-secondary opacity-7 text-end">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $bed_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $bed_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td>
                        <p class="text-xs font-weight-small mb-0"><?php echo e($key + 1); ?></p>
                      <td>
                        <p class="text-xs font-weight-bold mb-0"><?php echo e($bed_type->name); ?></p>
                      </td>
                      <td class="text-end">
                        <a href="<?php echo e(route('bed-types.edit',$bed_type->id)); ?>" class="btn btn-secondary font-weight-bold text-xs me-2" data-toggle="tooltip" data-original-title="Edit user">
                          Edit
                        </a>
                        <a href="javascript:;" class="btn btn-danger font-weight-bold text-xs" data-toggle="tooltip" data-original-title="Edit user">
                          Delete
                        </a>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td class="text-center" colspan="3">
                            No Data Found!
                      </td>
                    </tr>
                    <?php endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/suhas/WORK/hotel-booking/resources/views/admin/bed_types/index.blade.php ENDPATH**/ ?>